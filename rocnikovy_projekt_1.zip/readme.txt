author: Martin Mihal
Project is for school purpose it'll be attendance system.
Name of school: UK Bratislava - FMFI
Teacher : Kamil Maraz
